<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/styles.css">
	<link rel="shortcut icon" href="images/pig.png" type="image/x-icon" />
	<link rel="stylesheet" href="font_awesome/font-awesome-4.7.0/css/font-awesome.min.css">

	<title>Projeto Hércules</title>
</head>

<body>
	<div class="add-container">
		<h1>Adicionar Colaborador</h1>
		<form action="adicionar_action.php" method='POST'>
			<label for="nome">
				Nome: <br><input type="text" name="nome" id="nome" placeholder="..." required>
			</label>
			<label for="idade">
				Idade: <br><input type="number" name="idade" id="idade" placeholder="..." required>
			</label>
			<label for="sexo">
				Sexo: <br> 
				<select ID="sexo" name="sexo">
					<option value="M">Masculino</option>
					<option value="F">Feminino</option>
				</select><br>
			</label>
			<label for="sintomas_dor">
				Tem sintomas de dores?  <br> 
				<select ID="sintomas_dor" name="sintomas_dor">
					<option value="S">Sim</option>
					<option value="N">Não</option>
				</select><br>
			</label>
			<label for="mudanca_local">
				Houve mudança no local de trabalho? <br> 
				<select ID="mudanca_local" name="mudanca_local">
					<option value="S">Sim</option>
					<option value="N">Não</option>
				</select><br>
			</label>
			<label for="mudanca_funcao">
				Houve mudança de função?  <br> 
				<select ID="mudanca_funcao" name="mudanca_funcao">
					<option value="S">Sim</option>
					<option value="N">Não</option>
				</select><br>
			</label>
			<label for="dias_trabalhados">
				Total dias trabalhados: <br><input type="number" name="dias_trabalhados" id="dias_trabalhados" placeholder="..." required>
			</label>
			<label for="dias_atestado">
				Total dias atestado: <br><input type="number" name="dias_atestado" id="dias_atestado" placeholder="..." required>
			</label>
			<label for="carga_horaria_min">
				Carga Horária (minutos): <br><input type="number" name="carga_horaria_min" id="carga_horaria_min" placeholder="..." required>
			</label>
			  

  
			<br>
			<br>
			<button type="submit">Adicionar</button>
		</form>
	</div>
</body>

</html>
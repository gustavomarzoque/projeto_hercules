<?php
require 'config.php';

$id = $_GET['id'];

if ($id) {
  $sql = $pdo->prepare(
    'DELETE FROM colaborador WHERE id = :id'
  );

  $sql->bindParam(':id', $id);
  $sql->execute();

  header('Location: index.php');
  exit;
} else {
  header('Location: adicionar.php');
  exit;
}

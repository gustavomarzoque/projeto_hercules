<?php
	require('config.php');
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/styles.css">
	<link rel="shortcut icon" href="images/pig.png" type="image/x-icon" />
	<link rel="stylesheet" href="font_awesome/font-awesome-4.7.0/css/font-awesome.min.css">

	<title>Projeto Hércules</title>
</head>

<body>  
	<div class="header">
		<a href="adicionar.php"> + Novo Colaborador</a>
	</div>

	<table class="container">
		<tr> 
			<th>
				Ações 
			</th>
			<th>
				ID
			</th>
			<th>
				Nome
			</th>
			<th style="width:0%">
				Idade
			</th>
			<th style="width:0%">
				Sexo
			</th>
			<th style="width:0%">
				Dor?
			</th>
			<th style="width:0%">
				Mudança Local?
			</th>
			<th style="width:0%">
				Mudança Função?
			</th>
			<th style="width:0%">
				Dias Trabalhados
			</th>
			<th style="width:0%">
				Dias Atestado
			</th> 
			<th>
				Carga Horária 
			</th>
			<th>
				Risco - Árvore 1
			</th>
			<th>
				Risco - Árvore 2
			</th>
			<th>
				Risco - Árvore 3
			</th>

		</tr>
		<?php
		$sql  = "SELECT * from projeto_hercules.colaborador  ";
		$stmt = $pdo->prepare($sql);
		$stmt->execute();
		$last =  $stmt->fetchAll(PDO::FETCH_ASSOC);
		$html = '';

		try {
			foreach ($last as $row) {
				$html .= '<tr>';
				$html .= '<td style="display:flex;"><a  href="editar.php?id=' . $row['id'] . '"><i class="fa fa-pencil" style="color:green"></i></a>  <a href="excluir.php?id=' . $row['id'] . '"><i style="color:red" class="fa fa-trash"></i></a> </td>';
				$html .= '<td>' . $row['id'] . '</td>';

				$html .= '<td>' . $row['nome'] . '</td>';
				$html .= '<td>' . $row['idade'] . '</td>'; 
				if($row['sexo']=='M'){
					$html .= '<td><i style="color:#3333e9" class="fa fa-male"></i></td>';
				}else if ($row['sexo']=='F'){
					$html .= '<td><i style="color:#b741af"class="fa fa-female"></i></td>';
				}else{
					$html .= '<td>Outro</td>';
				}
				if($row['sintomas_dor'] == 'S'){
					$html .= '<td>Sim</td>'; 
				}else if($row['sintomas_dor'] == 'N') {
					$html .= '<td>Não</td>'; 
				}
				if($row['mudanca_local'] == 'S'){
					$html .= '<td>Sim</td>'; 
				}else if($row['mudanca_local'] == 'N') {
					$html .= '<td>Não</td>'; 
				}
				if($row['mudanca_funcao'] == 'S'){
					$html .= '<td>Sim</td>'; 
				}else if($row['mudanca_funcao'] == 'N') {
					$html .= '<td>Não</td>'; 
				}
				 
				$html .= '<td>' . $row['dias_trabalhados'] . '</td>'; 
				$html .= '<td>' . $row['dias_atestado'] . '</td>'; 
				$html .= '<td>' . $row['carga_horaria_min'] . ' Minutos/Dia</td>';   
				
				/*Arvore 1 - Change of functions/Health Issues  */
				if($row['mudanca_funcao'] == 'S'){
					if($row['dias_trabalhados'] > 540){
						if($row['idade'] > 59.5){
							$arvore1 = 'Alto';
						}else{
							$arvore1 = 'Médio';
						}
					}else{
						$arvore1 = 'Baixo';
					}
				}else{
					if($row['dias_trabalhados'] > 1642.5){
						$arvore1 = 'Alto';
					}else{
						if($row['mudanca_local'] == 'N'){
							if($row['dias_trabalhados'] > 390){
								$arvore1 = 'Alto';
							}else{
								$arvore1 = 'Baixo';
							}
						}else{
							if($row['idade'] > 55.5){
								$arvore1 = 'Alto'; 
							}else{
								if($row['dias_trabalhados'] > 450){
									$arvore1 = 'Médio'; 
								}else{
									$arvore1 = 'Baixo';  
								}
							}
						}
					}
				}
				
				if($arvore1 == 'Alto'){
					$html .= '<td style="background:red">'.$arvore1.'</td>';
				}else if($arvore1 == 'Médio'){
					$html .= '<td style="background:green">'.$arvore1.'</td>';
				}else{
					$html .= '<td style="background:blue">'.$arvore1.'</td>';
				} 
				/*Fim Arvore 1*/

				/*Arvore 2 - idade*/
				if($row['idade'] > 60.5){
					$arvore2 = 'Alto';
				}else{
					if($row['dias_trabalhados'] <=390){
						$arvore2 = 'Baixo';
					}
					else{
						if($row['sexo'] == 'M'){
							if($row['idade'] > 57.5){
								$arvore2 = 'Alto';
							}
							else{
								$arvore2 = 'Médio';
							}
						}
						else{
							if($row['idade'] <= 24.5){
								$arvore2 = 'Médio'; 
							}
							else{
								if($row['dias_trabalhados'] >1620){
									$arvore2 = 'Alto'; 
								}
								else{
									$arvore2 = 'Médio'; 
								}
							}
						}
					}
				}

				if($arvore2 == 'Alto'){
					$html .= '<td style="background:red">'.$arvore2.'</td>';
				}else if($arvore2 == 'Médio'){
					$html .= '<td style="background:green">'.$arvore2.'</td>';
				}else{
					$html .= '<td style="background:blue">'.$arvore2.'</td>';
				} 

				/*Fim Arvore 2*/
			

				
				/*Arvore 3 - sintomas de dor*/
				if($row['sintomas_dor'] == 'N'){
					$arvore3 = 'Baixo';
				}else{
					if($row['carga_horaria_min'] < 360){
						$arvore3 = 'Médio';
					}
					else{
						if($row['idade'] > 60.5){
							$arvore3 = 'Alto'; 
						}else{
							if($row['dias_trabalhados'] <= 390){
								$arvore3 = 'Baixo'; 
							}else{
								if($row['dias_trabalhados'] > 1980){
									$arvore3 = 'Alto';  
								}
								else{
									$arvore3 = 'Médio';  
								}
							}
						}
					}
				}

				if($arvore3 == 'Alto'){
					$html .= '<td style="background:red">'.$arvore3.'</td>';
				}else if($arvore3 == 'Médio'){
					$html .= '<td style="background:green">'.$arvore3.'</td>';
				}else{
					$html .= '<td style="background:blue">'.$arvore3.'</td>';
				}
				/*Fim Arvore 3*/

				 
				$html .= '</tr>';
			}
			echo ($html);
		} catch (PDOException $e) {
			echo 'Error: ' . $e->getMessage();
		};
		?>
	</table>
</body>

</html>
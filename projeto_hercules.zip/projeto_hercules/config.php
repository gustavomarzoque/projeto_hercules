<?php
$pdo = new PDO('mysql:dbname=projeto_hercules; host=localhost', 'root', '');
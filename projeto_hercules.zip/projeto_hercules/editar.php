<?php
require('config.php');

$info = [];
$id = filter_input(INPUT_GET, 'id'); 


if ($id) {
  $sql = $pdo->prepare("SELECT * FROM colaborador WHERE id = :id");
  $sql->bindParam(":id", $id);
  $sql->execute();

  if ($sql->rowCount() > 0) {
    $info = $sql->fetch(PDO::FETCH_ASSOC); 
  } else {
    header("Location: index.php");
    exit;
  }
} else {
  header("Location: index.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/styles.css">
	<link rel="shortcut icon" href="images/pig.png" type="image/x-icon" />
	<link rel="stylesheet" href="font_awesome/font-awesome-4.7.0/css/font-awesome.min.css">

	<title>Projeto Hércules</title>
</head>

<body>
  <div class="add-container">
    <h1>Editar Colaborador</h1>
    <form action="editar_action.php" method='POST'>
      <input type="hidden" name="id" id="id" value="<?= $info['id']; ?>">
      <label for="nome">
				Nome: <br><input type="text" name="nome" id="nome" placeholder="..." required value="<?= $info['nome']; ?>">
			</label>
			<label for="idade">
				Idade: <br><input type="number" name="idade" id="idade" placeholder="..." required value="<?= $info['idade']; ?>">
			</label>
      <?php
        $htmlsexo =  '';
        $htmlsexo .=  '<label for="sexo">';
        $htmlsexo .=  'Sexo: <br> ';
        $htmlsexo .=  '<select ID="sexo" name="sexo">';
        if($info['sexo']=='M'){
          $htmlsexo .=  '<option selected value="M">Masculino</option>';
          $htmlsexo .=  '<option value="F">Feminino</option>';
        }else{
          $htmlsexo .=  '<option value="M">Masculino</option>';
          $htmlsexo .=  '<option selected value="F">Feminino</option>';
        }
        
        $htmlsexo .=  '</select><br>';
        $htmlsexo .=  '</label>';
        echo $htmlsexo;
        ?>  
        <?php
        $htmlsintomas = '';
        $htmlsintomas .= '<label for="sintomas_dor">';
        $htmlsintomas .= 'Tem sintomas de dores?  <br>'; 
        $htmlsintomas .= '<select ID="sintomas_dor" name="sintomas_dor">';
        if($info['sintomas_dor']=='S'){
          $htmlsintomas .= '  <option selected value="S">Sim</option>';
          $htmlsintomas .= '  <option value="N">Não</option>';
        }else{
          $htmlsintomas .= '  <option value="S">Sim</option>';
          $htmlsintomas .= '  <option selected value="N">Não</option>';
        }
        $htmlsintomas .= '</select><br>';
        $htmlsintomas .= '</label>';
        echo $htmlsintomas;
        ?>  
        <?php
        $htmlmudancalocal = '';
        $htmlmudancalocal .= '<label for="mudanca_local">';
        $htmlmudancalocal .= 'Houve mudança no local de trabalho? <br> ';
        $htmlmudancalocal .= '<select ID="mudanca_local" name="mudanca_local">';
        if($info['mudanca_local']=='S'){
          $htmlmudancalocal .= '	<option selected value="S">Sim</option>';
          $htmlmudancalocal .= '  <option value="N">Não</option>';
        }else{
          $htmlmudancalocal .= '	<option value="S">Sim</option>';
          $htmlmudancalocal .= '  <option selected value="N">Não</option>'; 
        }
        $htmlmudancalocal .= '</select><br>';
        $htmlmudancalocal .= '</label>'; 
        echo $htmlmudancalocal;
        ?>

        <?php
        $htmlmudancafuncao = '';
        $htmlmudancafuncao .= '<label for="mudanca_funcao"> ';
        $htmlmudancafuncao .= 'Houve mudança de função?  <br>';
        $htmlmudancafuncao .= '<select ID="mudanca_funcao" name="mudanca_funcao" >';
        $htmlmudancafuncao .= '<option value="S">Sim</option>';
        $htmlmudancafuncao .= '<option value="N">Não</option>';
        $htmlmudancafuncao .= '</select><br>';
        $htmlmudancafuncao .= '</label>';
        echo $htmlmudancafuncao;
        ?> 
			
				 
				
					
					
				
			


			<label for="dias_trabalhados">
				Total dias trabalhados: <br><input type="number" name="dias_trabalhados" id="dias_trabalhados" placeholder="..." required value="<?= $info['dias_trabalhados']; ?>">
			</label>
			<label for="dias_atestado">
				Total dias atestado: <br><input type="number" name="dias_atestado" id="dias_atestado" placeholder="..." required value="<?= $info['dias_atestado']; ?>">
			</label>
			<label for="carga_horaria_min">
				Carga Horária (minutos): <br><input type="number" name="carga_horaria_min" id="carga_horaria_min" placeholder="..." required value="<?= $info['carga_horaria_min']; ?>">
			</label>

      <br>
      <br>
      <button type="submit">Salvar</button>
    </form>
  </div>
</body>

</html>
 
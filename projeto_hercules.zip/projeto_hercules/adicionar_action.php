<?php
require 'config.php';

 
$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
$idade = filter_input(INPUT_POST, 'idade', FILTER_SANITIZE_SPECIAL_CHARS);
$sexo = filter_input(INPUT_POST, 'sexo', FILTER_SANITIZE_SPECIAL_CHARS);
$sintomas_dor = filter_input(INPUT_POST, 'sintomas_dor', FILTER_SANITIZE_SPECIAL_CHARS);
$mudanca_local = filter_input(INPUT_POST, 'mudanca_local', FILTER_SANITIZE_SPECIAL_CHARS);
$mudanca_funcao = filter_input(INPUT_POST, 'mudanca_funcao', FILTER_SANITIZE_SPECIAL_CHARS);
$dias_trabalhados = filter_input(INPUT_POST, 'dias_trabalhados', FILTER_SANITIZE_SPECIAL_CHARS);
$carga_horaria_min = filter_input(INPUT_POST, 'carga_horaria_min', FILTER_SANITIZE_SPECIAL_CHARS);
$dias_atestado = filter_input(INPUT_POST, 'dias_atestado', FILTER_SANITIZE_SPECIAL_CHARS);

 

if ($nome) {
    $sql = $pdo->prepare(
        'INSERT INTO colaborador (nome,idade,sexo,sintomas_dor,mudanca_local,mudanca_funcao,dias_trabalhados,carga_horaria_min,dias_atestado) VALUES (:nome,:idade,:sexo,:sintomas_dor,:mudanca_local,:mudanca_funcao,:dias_trabalhados,:carga_horaria_min,:dias_atestado) '
    );

    $sql->bindParam(':nome', $nome);
    $sql->bindParam(':idade', $idade);
    $sql->bindParam(':sexo', $sexo);
    $sql->bindParam(':sintomas_dor', $sintomas_dor);
    $sql->bindParam(':mudanca_local', $mudanca_local);
    $sql->bindParam(':mudanca_funcao', $mudanca_funcao);
    $sql->bindParam(':dias_trabalhados', $dias_trabalhados);
    $sql->bindParam(':carga_horaria_min', $carga_horaria_min);
    $sql->bindParam(':dias_atestado', $dias_atestado);
    $sql->execute();

    header('Location: index.php');
    exit;
} else {
    header('Location: adicionar.php');
    exit;
}